
# ADHD Learning App

A clean, AI-powered landing page designed for adults with ADHD. Features personalized learning, microlearning modules, and a built-in study assistant chatbot.

## Features

- Responsive TailwindCSS layout
- AI-powered ADHD chatbot via Chatbase
- Formspree email collection form
- JavaScript-powered success message
- SEO meta tags and Open Graph tags

## Setup

1. Replace `YOUR-FORM-ID` in the form action with your Formspree form ID.
2. Deploy with GitHub Pages, Vercel, or Netlify.

## License

MIT License
